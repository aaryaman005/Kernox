from fastapi import APIRouter, Depends, Query, HTTPException, Path
from sqlalchemy.orm import Session
from sqlalchemy import asc, desc
from datetime import datetime, timezone

from app.db.session import get_db
from app.models.alert import Alert
from app.models.alert_status_history import AlertStatusHistory
from app.schemas.alert_read_schema import AlertListResponse, AlertRead

router = APIRouter()

# ─────────────────────────────────────────────
# CONSTANTS
# ─────────────────────────────────────────────

MAX_PAGE_SIZE = 100

ALLOWED_STATUSES = {"open", "acknowledged", "resolved"}

ALLOWED_TRANSITIONS = {
    "open": {"acknowledged", "resolved"},
    "acknowledged": {"resolved"},
    "resolved": set(),  # terminal state
}


def get_sortable_fields():
    """
    Lazy mapping to avoid import-order issues.
    """
    return {
        "created_at": Alert.created_at,
        "risk_score": Alert.risk_score,
        "severity": Alert.severity,
        "status": Alert.status,
    }


# ─────────────────────────────────────────────
# Alert Query API
# GET /alerts
# ─────────────────────────────────────────────
@router.get("/alerts", response_model=AlertListResponse)
def list_alerts(
    db: Session = Depends(get_db),
    endpoint_id: int | None = Query(default=None),
    severity: str | None = Query(default=None),
    status: str | None = Query(default=None),
    min_risk: int | None = Query(default=None, ge=0),
    max_risk: int | None = Query(default=None, ge=0),
    page: int = Query(default=1, ge=1),
    page_size: int = Query(default=20, ge=1),
    sort_by: str = Query(default="created_at"),
    sort_order: str = Query(default="desc"),
):
    if page_size > MAX_PAGE_SIZE:
        raise HTTPException(
            status_code=400,
            detail=f"page_size cannot exceed {MAX_PAGE_SIZE}",
        )

    sortable_fields = get_sortable_fields()

    if sort_by not in sortable_fields:
        raise HTTPException(
            status_code=400,
            detail="Invalid sort_by field",
        )

    query = db.query(Alert)

    # Filters
    if endpoint_id is not None:
        query = query.filter(Alert.endpoint_id == endpoint_id)

    if severity is not None:
        query = query.filter(Alert.severity == severity)

    if status is not None:
        query = query.filter(Alert.status == status)

    if min_risk is not None:
        query = query.filter(Alert.risk_score >= min_risk)

    if max_risk is not None:
        query = query.filter(Alert.risk_score <= max_risk)

    total = query.count()

    # Sorting
    sort_column = sortable_fields[sort_by]
    query = query.order_by(
        asc(sort_column) if sort_order == "asc" else desc(sort_column)
    )

    # Pagination
    alerts = (
        query
        .offset((page - 1) * page_size)
        .limit(page_size)
        .all()
    )

    return AlertListResponse(
        total=total,
        page=page,
        page_size=page_size,
        results=[AlertRead.model_validate(alert) for alert in alerts],
    )


# ─────────────────────────────────────────────
# Alert Detail API
# GET /alerts/{id}
# ─────────────────────────────────────────────
@router.get("/alerts/{alert_id}", response_model=AlertRead)
def get_alert_detail(
    alert_id: int = Path(..., ge=1),
    db: Session = Depends(get_db),
):
    alert = db.query(Alert).filter(Alert.id == alert_id).first()

    if not alert:
        raise HTTPException(
            status_code=404,
            detail="Alert not found",
        )

    return AlertRead.model_validate(alert)


# ─────────────────────────────────────────────
# Controlled Lifecycle + Status History
# PATCH /alerts/{id}/status
# ─────────────────────────────────────────────
@router.patch("/alerts/{alert_id}/status", response_model=AlertRead)
def update_alert_status(
    alert_id: int = Path(..., ge=1),
    new_status: str = Query(...),
    db: Session = Depends(get_db),
):
    if new_status not in ALLOWED_STATUSES:
        raise HTTPException(
            status_code=400,
            detail="Invalid status value",
        )

    alert = db.query(Alert).filter(Alert.id == alert_id).first()

    if not alert:
        raise HTTPException(
            status_code=404,
            detail="Alert not found",
        )

    current_status = alert.status

    # Idempotent update
    if new_status == current_status:
        return AlertRead.model_validate(alert)

    # Deterministic transition enforcement
    if new_status not in ALLOWED_TRANSITIONS.get(current_status, set()):
        raise HTTPException(
            status_code=400,
            detail="Invalid status transition",
        )

    # Status history record
    history = AlertStatusHistory(
        alert_id=alert.id,
        previous_status=current_status,
        new_status=new_status,
        changed_at=datetime.now(timezone.utc),
    )

    alert.status = new_status

    db.add(history)
    db.commit()
    db.refresh(alert)

    return AlertRead.model_validate(alert)
