from typing import Dict, List
from app.models.alert import Alert


class RiskEngine:
    """
    Deterministic, explainable risk scoring engine.
    No DB writes.
    Pure logic.
    """

    CRITICAL_BONUS = 20
    MULTI_RULE_BONUS = 15
    CHAIN_LENGTH_BONUS = 10
    MAX_SCORE = 100

    @staticmethod
    def compute_campaign_score(alerts: List[Alert]) -> Dict:
        """
        Returns:
        {
            "base_score": int,
            "bonuses": {
                "critical_bonus": int,
                "multi_rule_bonus": int,
                "chain_length_bonus": int
            },
            "final_score": int
        }
        """

        base_score = sum(alert.risk_score for alert in alerts)

        bonuses = {
            "critical_bonus": 0,
            "multi_rule_bonus": 0,
            "chain_length_bonus": 0,
        }

        # Critical bonus
        if any(alert.severity == "critical" for alert in alerts):
            bonuses["critical_bonus"] = RiskEngine.CRITICAL_BONUS

        # Multi-rule bonus
        unique_rules = {alert.rule_name for alert in alerts}
        if len(unique_rules) >= 2:
            bonuses["multi_rule_bonus"] = RiskEngine.MULTI_RULE_BONUS

        # Chain length bonus
        if len(alerts) >= 3:
            bonuses["chain_length_bonus"] = RiskEngine.CHAIN_LENGTH_BONUS

        final_score = base_score + sum(bonuses.values())
        final_score = min(final_score, RiskEngine.MAX_SCORE)

        return {
            "base_score": base_score,
            "bonuses": bonuses,
            "final_score": final_score,
        }
